public class TestHarness 
{
    public static void main(String[] args) throws InterruptedException {
        Store store = new Store();
        store.Menu();
    }
}